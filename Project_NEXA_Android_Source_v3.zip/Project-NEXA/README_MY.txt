PROJECT NEXA ANDROID SOURCE
============================

GitHub တင်ရန်:
1. ZIP ကို Extract လုပ်ပါ။
2. Project-NEXA folder အတွင်းရှိ ဖိုင်/Folder အားလုံးကို GitHub repository root သို့ upload လုပ်ပါ။
3. .github/workflows/android-apk.yml ကို မပျောက်စေပါနှင့်။
4. Commit changes လုပ်ပါ။
5. Actions > Build NEXA Android APK > Run workflow ကိုနှိပ်ပါ။
6. Build အောင်မြင်လျှင် NEXA-debug-apk artifact ကို download လုပ်ပါ။
7. Artifact ZIP ကို Extract လုပ်ပြီး app-debug.apk ကို install လုပ်ပါ။

သတိပြုရန်:
- ဤသည် debug APK ဖြစ်ပြီး Play Store release signing မပါဝင်ပါ။
- လက်ရှိ app သည် local-only ဖြစ်သည်။ ဒေတာကို ဖုန်းအတွင်း local storage ဖြင့် သိမ်းသည်။
- Real AI API, cloud sync, account login, push notifications နှင့် payment မပါဝင်သေးပါ။
- App ကို uninstall သို့မဟုတ် app data clear လုပ်လျှင် local data ပျောက်နိုင်သည်။ Backup ကို ပုံမှန်ထုတ်ပါ။
